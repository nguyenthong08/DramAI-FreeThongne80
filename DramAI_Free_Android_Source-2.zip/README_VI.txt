DramAI Free — dự án mẫu Android

ĐÂY LÀ GÌ?
- Mã nguồn ứng dụng Android mẫu, giao diện tối, tìm kiếm trong danh sách video demo và phát video qua Internet.
- Không phải APK cài trực tiếp.
- Chưa có AI tạo video, chưa có thư viện phim dài tập, chưa có tài khoản, tải ngoại tuyến hoặc máy chủ nội dung.
- Chỉ thêm phim/video mà bạn sở hữu hoặc có giấy phép phát lại. Không có nội dung DramaWave độc quyền trong dự án.

BIÊN DỊCH APK
Cần Android Studio/Gradle hoặc một dịch vụ build Android. Workflow GitHub Actions đi kèm có thể build APK khi dự án được đưa lên GitHub:
1. Tạo repository GitHub mới và tải các tệp dự án lên.
2. Vào tab Actions, chọn “Build Android APK”, bấm Run workflow.
3. Khi chạy xong, mở run đó và tải artifact “DramAI-Free-debug-apk”.
Lưu ý: thao tác này vẫn cần tài khoản GitHub và tải tệp lên; mình không thể đăng nhập hoặc tạo repository thay bạn.

CÀI ĐẶT
APK debug tải từ artifact thường là app-debug.apk. Trên điện thoại Android, mở tệp APK và làm theo lời nhắc cài đặt từ nguồn bạn chọn.

VIDEO DEMO
Danh sách dùng các URL demo công khai để kiểm tra trình phát. Video cần Internet và nguồn có thể thay đổi. Hãy xác minh quyền sử dụng và điều kiện giấy phép trước khi phân phối ứng dụng.
