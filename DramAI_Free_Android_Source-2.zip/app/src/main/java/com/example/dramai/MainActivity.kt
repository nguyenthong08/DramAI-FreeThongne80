package com.example.dramai

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

data class Drama(val title: String, val genre: String, val description: String, val url: String)

class MainActivity : Activity() {
    private val bg = Color.rgb(15, 16, 22)
    private val card = Color.rgb(31, 33, 44)
    private val accent = Color.rgb(255, 75, 120)
    private val catalog = listOf(
        Drama("Big Buck Bunny", "Hoạt hình • Miễn phí", "Phim hoạt hình mẫu để thử trình phát. Hãy kiểm tra giấy phép và nguồn trước khi thêm phim khác.",
            "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
        Drama("Elephant Dream", "Hoạt hình • Miễn phí", "Video mẫu thuộc dự án phim mở Blender; hãy đọc điều kiện giấy phép trước khi tái sử dụng.",
            "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
        Drama("For Bigger Escapes", "Video demo", "Video demo trình phát, không phải phim bộ.",
            "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 24, 18, 18)
            setBackgroundColor(bg)
        }
        page.addView(TextView(this).apply {
            text = "DramAI"; textSize = 32f; setTextColor(Color.WHITE)
            setTypeface(null, android.graphics.Typeface.BOLD)
        })
        page.addView(TextView(this).apply {
            text = "PHIM NGẮN • NỘI DUNG MIỄN PHÍ HỢP PHÁP"
            textSize = 11f; setTextColor(accent); setPadding(0, 4, 0, 18)
        })

        val search = EditText(this).apply {
            hint = "Tìm phim hoặc thể loại…"
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setPadding(14, 10, 14, 10)
            setBackgroundColor(card)
        }
        page.addView(search)

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 14, 0, 20) }
        scroll.addView(list)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun render(query: String = "") {
            list.removeAllViews()
            val filtered = catalog.filter {
                it.title.contains(query, true) || it.genre.contains(query, true) ||
                    it.description.contains(query, true)
            }
            if (filtered.isEmpty()) {
                list.addView(TextView(this).apply {
                    text = "Không tìm thấy phim trong danh sách demo."
                    setTextColor(Color.WHITE); textSize = 15f; setPadding(4, 24, 4, 24)
                })
            }
            filtered.forEach { drama ->
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(16, 16, 16, 16)
                    setBackgroundColor(card)
                }
                box.addView(TextView(this).apply {
                    text = "▶"; textSize = 24f; gravity = Gravity.CENTER
                    setTextColor(accent); setPadding(0, 8, 0, 8)
                })
                box.addView(TextView(this).apply {
                    text = drama.title; textSize = 20f
                    setTextColor(Color.WHITE); setTypeface(null, android.graphics.Typeface.BOLD)
                })
                box.addView(TextView(this).apply {
                    text = drama.genre; textSize = 12f; setTextColor(accent); setPadding(0, 4, 0, 6)
                })
                box.addView(TextView(this).apply {
                    text = drama.description; textSize = 13f; setTextColor(Color.LTGRAY)
                })
                box.addView(Button(this).apply {
                    text = "XEM MIỄN PHÍ"
                    setOnClickListener {
                        startActivity(Intent(this@MainActivity, PlayerActivity::class.java).apply {
                            putExtra("title", drama.title)
                            putExtra("url", drama.url)
                        })
                    }
                })
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.bottomMargin = 12
                list.addView(box, lp)
            }
            list.addView(TextView(this).apply {
                text = "\nĐây là bản mẫu. Chưa có thư viện phim dài tập hoặc chức năng tạo phim AI."
                setTextColor(Color.LTGRAY); textSize = 12f
            })
        }
        search.addTextChangedListener(SimpleTextWatcher { render(it) })
        render()
        setContentView(page)
    }
}
