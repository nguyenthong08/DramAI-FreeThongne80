package com.example.dramai

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView
import android.widget.Toast

class PlayerActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        val title = intent.getStringExtra("title") ?: "Đang phát"
        val url = intent.getStringExtra("url") ?: return
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 24, 16, 16)
            setBackgroundColor(Color.rgb(15, 16, 22))
        }
        layout.addView(TextView(this).apply {
            text = "‹  $title"; textSize = 22f; setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 18)
            setOnClickListener { finish() }
        })
        val video = VideoView(this)
        layout.addView(video, LinearLayout.LayoutParams(-1, 0, 1f))
        layout.addView(TextView(this).apply {
            text = "Nếu video không phát, hãy kiểm tra kết nối mạng hoặc nguồn video."
            textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(4, 16, 4, 10)
        })
        setContentView(layout)
        val controls = MediaController(this)
        controls.setAnchorView(video)
        video.setMediaController(controls)
        video.setVideoURI(Uri.parse(url))
        video.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Không phát được video mẫu.", Toast.LENGTH_LONG).show()
            true
        }
        video.setOnPreparedListener { it.start() }
    }
}
